import React from 'react';

const Collections = () => {
  return (
    <section style={styles.container}>
      <h3 style={styles.heading}>Featured Pieces</h3>

      <div style={styles.grid}>
        <div style={styles.card}></div>
        <div style={styles.card}></div>
        <div style={styles.card}></div>
      </div>
    </section>
  );
};

const styles = {
  container: {
    padding: '60px 48px'
  },
  heading: {
    fontSize: '28px',
    marginBottom: '24px'
  },
  grid: {
    display: 'flex',
    gap: '20px'
  },
  card: {
    width: '200px',
    height: '220px',
    backgroundColor: '#f5f5f5',
    borderRadius: '8px'
  }
};

export default Collections;
