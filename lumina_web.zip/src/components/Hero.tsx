import React from 'react';

const Hero = () => {
  return (
    <section style={styles.container}>
      <h2 style={styles.title}>Define Your Moment</h2>
      <p style={styles.subtitle}>Hand‑crafted elegance made for your story.</p>
      <button style={styles.button}>Explore Collection</button>
    </section>
  );
};

const styles = {
  container: {
    height: '70vh',
    background: 'linear-gradient(to bottom right, #ffffff, #f8f4ee)',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    paddingLeft: '48px'
  },
  title: {
    fontSize: '48px',
    fontWeight: '700',
    marginBottom: '12px'
  },
  subtitle: {
    fontSize: '20px',
    opacity: 0.7,
    marginBottom: '24px'
  },
  button: {
    width: '200px',
    padding: '12px 0',
    fontSize: '16px',
    borderRadius: '6px',
    border: 'none',
    backgroundColor: '#000',
    color: '#fff',
    cursor: 'pointer'
  }
};

export default Hero;
