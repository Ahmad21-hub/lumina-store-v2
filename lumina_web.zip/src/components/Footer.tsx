import React from 'react';

const Footer = () => {
  return (
    <footer style={styles.footer}>
      <p>© 2025 Lumina Jewelry. All rights reserved.</p>
    </footer>
  );
};

const styles = {
  footer: {
    width: '100%',
    padding: '24px',
    textAlign: 'center',
    backgroundColor: '#fafafa',
    borderTop: '1px solid #eee',
    marginTop: '40px'
  }
};

export default Footer;
