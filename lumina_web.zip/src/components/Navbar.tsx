import React from 'react';

const Navbar = () => {
  return (
    <nav style={styles.nav}>
      <h1 style={styles.logo}>Lumina</h1>
    </nav>
  );
};

const styles = {
  nav: {
    width: '100%',
    padding: '16px 32px',
    display: 'flex',
    justifyContent: 'flex-start',
    backgroundColor: '#ffffff',
    borderBottom: '1px solid #eee'
  },
  logo: {
    fontSize: '24px',
    fontWeight: '600',
    color: '#000'
  }
};

export default Navbar;
